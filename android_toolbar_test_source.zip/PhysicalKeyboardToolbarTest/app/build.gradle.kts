plugins { id("com.android.application") }

android {
    namespace = "com.taehwan.physicaltoolbartest"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.taehwan.physicaltoolbartest"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "0.1-test"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
