package com.taehwan.physicaltoolbartest;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.input.InputManager;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public final class ToolbarService extends Service implements InputManager.InputDeviceListener {
    private static final String CHANNEL_ID = "physical_toolbar_test";
    private static final int NOTIFICATION_ID = 1001;

    private InputManager inputManager;
    private WindowManager windowManager;
    private View toolbarView;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("물리 키보드 툴바 테스트")
                .setContentText("외장 키보드 연결 상태를 감지 중")
                .setOngoing(true)
                .build();
        startForeground(NOTIFICATION_ID, notification);

        inputManager = (InputManager) getSystemService(Context.INPUT_SERVICE);
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        inputManager.registerInputDeviceListener(this, null);
        refreshToolbar();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        refreshToolbar();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (inputManager != null) inputManager.unregisterInputDeviceListener(this);
        hideToolbar();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onInputDeviceAdded(int deviceId) { refreshToolbar(); }
    @Override public void onInputDeviceRemoved(int deviceId) { refreshToolbar(); }
    @Override public void onInputDeviceChanged(int deviceId) { refreshToolbar(); }

    private void refreshToolbar() {
        if (!Settings.canDrawOverlays(this)) {
            hideToolbar();
            return;
        }
        if (hasPhysicalAlphabeticKeyboard()) showToolbar();
        else hideToolbar();
    }

    private boolean hasPhysicalAlphabeticKeyboard() {
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice d = InputDevice.getDevice(id);
            if (d == null || d.isVirtual()) continue;
            if ((d.getSources() & InputDevice.SOURCE_KEYBOARD) != InputDevice.SOURCE_KEYBOARD) continue;
            if (d.getKeyboardType() == InputDevice.KEYBOARD_TYPE_ALPHABETIC) return true;
        }
        return false;
    }

    private void showToolbar() {
        if (toolbarView != null) return;

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), 0, dp(10), 0);
        bar.setBackgroundColor(Color.rgb(245, 245, 245));
        bar.setElevation(dp(8));

        TextView state = makeItem("⌨  연결됨", false);
        bar.addView(state, weighted(1.5f));
        bar.addView(makeItem("클립보드", true), weighted(1f));
        bar.addView(makeItem("이모지", true), weighted(1f));
        bar.addView(makeItem("🌐", true), weighted(0.65f));
        bar.addView(makeItem("×", true), weighted(0.55f));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                dp(52),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.BOTTOM;
        lp.x = 0;
        lp.y = 0;

        try {
            windowManager.addView(bar, lp);
            toolbarView = bar;
        } catch (Exception e) {
            toolbarView = null;
        }
    }

    private TextView makeItem(String text, boolean clickable) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.BLACK);
        v.setTextSize(14f);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        if (clickable) {
            v.setBackgroundResource(android.R.drawable.list_selector_background);
            if ("×".equals(text)) {
                v.setOnClickListener(view -> hideToolbar());
            } else {
                v.setOnClickListener(view ->
                        Toast.makeText(this, text + " 버튼 테스트", Toast.LENGTH_SHORT).show());
            }
        }
        return v;
    }

    private LinearLayout.LayoutParams weighted(float weight) {
        return new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, weight);
    }

    private void hideToolbar() {
        if (toolbarView == null) return;
        try { windowManager.removeView(toolbarView); } catch (Exception ignored) {}
        toolbarView = null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID, "Physical toolbar test", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("물리 키보드 연결 감지 테스트 서비스");
            nm.createNotificationChannel(c);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
