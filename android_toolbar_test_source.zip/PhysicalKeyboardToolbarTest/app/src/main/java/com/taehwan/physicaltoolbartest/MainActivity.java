package com.taehwan.physicaltoolbartest;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(32), dp(24), dp(24));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("Physical Keyboard Toolbar Test");
        title.setTextSize(22f);
        title.setTextColor(Color.BLACK);
        root.addView(title, matchWrap());

        TextView info = new TextView(this);
        info.setText("다른 앱 위에 표시 권한을 허용하면, 외장 물리 키보드가 연결된 동안 화면 맨 아래에 테스트 툴바를 표시합니다.\n\n툴바 버튼은 표시/터치 테스트용입니다.");
        info.setTextSize(16f);
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, dp(20), 0, dp(20));
        root.addView(info, matchWrap());

        status = new TextView(this);
        status.setTextSize(16f);
        status.setTextColor(Color.BLACK);
        status.setPadding(0, 0, 0, dp(16));
        root.addView(status, matchWrap());

        Button permission = new Button(this);
        permission.setText("오버레이 권한 허용");
        permission.setOnClickListener(v -> openOverlayPermission());
        root.addView(permission, matchWrap());

        Button start = new Button(this);
        start.setText("테스트 서비스 시작");
        start.setOnClickListener(v -> startToolbarService());
        root.addView(start, matchWrap());

        Button stop = new Button(this);
        stop.setText("테스트 서비스 중지");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, ToolbarService.class));
            updateStatus();
        });
        root.addView(stop, matchWrap());

        setContentView(root);

        if (!Settings.canDrawOverlays(this)) {
            openOverlayPermission();
        } else {
            startToolbarService();
        }
        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Settings.canDrawOverlays(this)) {
            startToolbarService();
        }
        updateStatus();
    }

    private void openOverlayPermission() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    private void startToolbarService() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlayPermission();
            return;
        }
        Intent intent = new Intent(this, ToolbarService.class);
        startForegroundService(intent);
        updateStatus();
    }

    private void updateStatus() {
        if (status == null) return;
        status.setText(Settings.canDrawOverlays(this)
                ? "오버레이 권한: 허용됨"
                : "오버레이 권한: 필요함");
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
