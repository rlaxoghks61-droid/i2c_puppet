plugins {
    id("com.android.application")
}

android {
    namespace = "com.bbq20kbd.toolbar.test"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.bbq20kbd.toolbar.test"
        minSdk = 31
        targetSdk = 36
        versionCode = 4
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
