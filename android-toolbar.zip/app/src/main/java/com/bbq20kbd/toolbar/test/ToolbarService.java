package com.bbq20kbd.toolbar.test;

import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.input.InputManager;
import android.net.Uri;
import android.os.IBinder;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.View;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ToolbarService extends Service implements InputManager.InputDeviceListener {
    private static final int TOOLBAR_HEIGHT_DP = 36;
    private static final int TOOLBAR_TRANSPARENCY_PERCENT = 80;
    private static final int MAX_HISTORY = 12;

    private static final String[] EMOJI = {
            "😀","😂","🥰","😍","😊","😉","😎","🥳","😭","😡",
            "👍","👎","👌","🙏","👏","💪","❤️","💕","🔥","✨",
            "✅","❌","⚠️","💡","🎉","🎁","📌","📎","⭐","💯"
    };

    private static final String[] SYMBOLS = {
            "!","?","…","~","@","#","$","%","&","*",
            "(",")","[","]","{","}","<",">","+","=",
            "-","_","/","\\","|","^","°","·","•","©",
            "®","™","✓","→","←","↑","↓","♥","★","☆",
            "₩","$","€","¥","£","₽","₹","§","¶","※"
    };

    private InputManager inputManager;
    private WindowManager windowManager;
    private ClipboardManager clipboardManager;
    private SharedPreferences prefs;
    private View toolbar;
    private View panel;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;

    @Override
    public void onCreate() {
        super.onCreate();
        inputManager = (InputManager) getSystemService(Context.INPUT_SERVICE);
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        prefs = getSharedPreferences("toolbar", MODE_PRIVATE);
        if (inputManager != null) inputManager.registerInputDeviceListener(this, null);
        if (clipboardManager != null) {
            clipListener = this::captureClipboardIfReadable;
            clipboardManager.addPrimaryClipChangedListener(clipListener);
        }
        updateToolbar();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        updateToolbar();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (inputManager != null) inputManager.unregisterInputDeviceListener(this);
        if (clipboardManager != null && clipListener != null) {
            clipboardManager.removePrimaryClipChangedListener(clipListener);
        }
        hidePanel();
        hideToolbar();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override public void onInputDeviceAdded(int deviceId) { updateToolbar(); }
    @Override public void onInputDeviceRemoved(int deviceId) { updateToolbar(); }
    @Override public void onInputDeviceChanged(int deviceId) { updateToolbar(); }

    private void updateToolbar() {
        if (!Settings.canDrawOverlays(this) || !hasExternalAlphabeticKeyboard() || !isCoverLikeDisplay()) {
            hidePanel();
            hideToolbar();
            return;
        }
        showToolbar();
    }

    private boolean hasExternalAlphabeticKeyboard() {
        int[] ids = InputDevice.getDeviceIds();
        for (int id : ids) {
            InputDevice d = InputDevice.getDevice(id);
            if (d == null || d.isVirtual()) continue;
            if ((d.getSources() & InputDevice.SOURCE_KEYBOARD) != InputDevice.SOURCE_KEYBOARD) continue;
            if (d.getKeyboardType() != InputDevice.KEYBOARD_TYPE_ALPHABETIC) continue;
            return true;
        }
        return false;
    }

    private boolean isCoverLikeDisplay() {
        if (windowManager == null) return true;
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(dm);
        int min = Math.min(dm.widthPixels, dm.heightPixels);
        int max = Math.max(dm.widthPixels, dm.heightPixels);
        if (max == 0) return true;
        return ((float) min / (float) max) >= 0.70f;
    }

    private void showToolbar() {
        if (toolbar != null || windowManager == null) return;

        final boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        final int iconColor = dark ? Color.WHITE : Color.BLACK;
        final int baseRgb = dark ? Color.BLACK : Color.WHITE;
        final int alpha = Math.round(255f * (100 - TOOLBAR_TRANSPARENCY_PERCENT) / 100f);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(dp(2), 0, dp(2), 0);
        bar.setBackgroundColor(Color.argb(alpha, Color.red(baseRgb), Color.green(baseRgb), Color.blue(baseRgb)));

        addToolbarButton(bar, "📋", "클립보드", iconColor, v -> showClipboardPanel());
        addToolbarButton(bar, "😀", "이모지", iconColor, v -> showGridPanel("이모지", EMOJI));
        addToolbarButton(bar, "#+=", "특수문자", iconColor, v -> showGridPanel("특수문자", SYMBOLS));
        addToolbarButton(bar, "文", "번역", iconColor, v -> translateSelection());
        addToolbarButton(bar, "✎", "텍스트 편집", iconColor, v -> showEditPanel());
        addToolbarButton(bar, "⋯", "더보기", iconColor, v -> showMorePanel());

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                dp(TOOLBAR_HEIGHT_DP),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.BOTTOM;
        lp.setTitle("HardwareKeyboardToolbar");

        try {
            windowManager.addView(bar, lp);
            toolbar = bar;
        } catch (Exception ignored) {
            toolbar = null;
        }
    }

    private void addToolbarButton(LinearLayout bar, String text, String description, int color, View.OnClickListener listener) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextColor(color);
        button.setTextSize(text.length() > 2 ? 12f : 18f);
        button.setGravity(Gravity.CENTER);
        button.setContentDescription(description);
        button.setPadding(dp(2), 0, dp(2), 0);
        button.setOnClickListener(listener);
        button.setOnLongClickListener(v -> {
            Toast.makeText(this, description, Toast.LENGTH_SHORT).show();
            return true;
        });
        bar.addView(button, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.MATCH_PARENT, 1f));
    }

    private void showClipboardPanel() {
        captureClipboardIfReadable();
        LinearLayout content = panelContainer();
        addPanelTitle(content, "클립보드");

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(panelAction("붙여넣기", v -> {
            KeyboardAccessibilityService a = KeyboardAccessibilityService.get();
            if (a != null && a.pasteClipboard()) hidePanel();
            else accessibilityNeeded();
        }), new LinearLayout.LayoutParams(0, dp(38), 1f));
        actions.addView(panelAction("복사", v -> {
            KeyboardAccessibilityService a = KeyboardAccessibilityService.get();
            if (a != null && a.copySelection()) {
                captureClipboardIfReadable();
                hidePanel();
            } else accessibilityNeeded();
        }), new LinearLayout.LayoutParams(0, dp(38), 1f));
        actions.addView(panelAction("잘라내기", v -> {
            KeyboardAccessibilityService a = KeyboardAccessibilityService.get();
            if (a != null && a.cutSelection()) {
                captureClipboardIfReadable();
                hidePanel();
            } else accessibilityNeeded();
        }), new LinearLayout.LayoutParams(0, dp(38), 1f));
        content.addView(actions, new LinearLayout.LayoutParams(-1, dp(38)));

        List<String> history = loadHistory();
        if (history.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("최근 텍스트 없음");
            empty.setTextColor(panelSubTextColor());
            empty.setGravity(Gravity.CENTER);
            content.addView(empty, new LinearLayout.LayoutParams(-1, dp(44)));
        } else {
            for (String item : history) {
                String display = item.replace('\n', ' ');
                if (display.length() > 60) display = display.substring(0, 60) + "…";
                TextView row = panelAction(display, v -> insertText(item));
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), 0, dp(8), 0);
                content.addView(row, new LinearLayout.LayoutParams(-1, dp(38)));
            }
        }
        showPanel(content, Math.min(dp(250), dp(84 + Math.min(history.size(), 4) * 38)));
    }

    private void showGridPanel(String title, String[] values) {
        LinearLayout content = panelContainer();
        addPanelTitle(content, title);

        ScrollView scroll = new ScrollView(this);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(10);
        grid.setPadding(dp(4), 0, dp(4), dp(4));
        for (String value : values) {
            TextView cell = new TextView(this);
            cell.setText(value);
            cell.setTextSize(title.equals("이모지") ? 20f : 17f);
            cell.setTextColor(panelTextColor());
            cell.setGravity(Gravity.CENTER);
            cell.setOnClickListener(v -> insertText(value));
            GridLayout.LayoutParams glp = new GridLayout.LayoutParams();
            glp.width = 0;
            glp.height = dp(38);
            glp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            grid.addView(cell, glp);
        }
        scroll.addView(grid);
        content.addView(scroll, new LinearLayout.LayoutParams(-1, dp(124)));
        showPanel(content, dp(156));
    }

    private void showEditPanel() {
        LinearLayout content = panelContainer();
        addPanelTitle(content, "텍스트 편집");

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        addEditAction(row1, "전체선택", () -> withAccessibility(a -> a.selectAll()));
        addEditAction(row1, "복사", () -> withAccessibility(a -> a.copySelection()));
        addEditAction(row1, "잘라내기", () -> withAccessibility(a -> a.cutSelection()));
        addEditAction(row1, "붙여넣기", () -> withAccessibility(a -> a.pasteClipboard()));
        content.addView(row1, new LinearLayout.LayoutParams(-1, dp(40)));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        addEditAction(row2, "|←", () -> withAccessibility(a -> a.moveCursorToEdge(false)));
        addEditAction(row2, "←", () -> withAccessibility(a -> a.moveCursor(-1)));
        addEditAction(row2, "→", () -> withAccessibility(a -> a.moveCursor(1)));
        addEditAction(row2, "→|", () -> withAccessibility(a -> a.moveCursorToEdge(true)));
        content.addView(row2, new LinearLayout.LayoutParams(-1, dp(40)));
        showPanel(content, dp(112));
    }

    private void showMorePanel() {
        LinearLayout content = panelContainer();
        addPanelTitle(content, "더보기");

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        addEditAction(row1, "웹 검색", this::searchSelection);
        addEditAction(row1, "공유", this::shareSelection);
        addEditAction(row1, "날짜", () -> insertText(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date())));
        addEditAction(row1, "시간", () -> insertText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date())));
        content.addView(row1, new LinearLayout.LayoutParams(-1, dp(40)));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        addEditAction(row2, "설정", this::openAppSettings);
        addEditAction(row2, "접근성", this::openAccessibilitySettings);
        content.addView(row2, new LinearLayout.LayoutParams(-1, dp(40)));
        showPanel(content, dp(112));
    }

    private interface AccessibilityAction { boolean run(KeyboardAccessibilityService service); }

    private void withAccessibility(AccessibilityAction action) {
        KeyboardAccessibilityService a = KeyboardAccessibilityService.get();
        if (a == null) {
            accessibilityNeeded();
            return;
        }
        if (!action.run(a)) Toast.makeText(this, "현재 입력 칸에서 사용할 수 없습니다.", Toast.LENGTH_SHORT).show();
    }

    private void addEditAction(LinearLayout row, String label, Runnable action) {
        TextView view = panelAction(label, v -> action.run());
        row.addView(view, new LinearLayout.LayoutParams(0, dp(40), 1f));
    }

    private void translateSelection() {
        String text = selectedOrClipboardText();
        if (TextUtils.isEmpty(text)) {
            Toast.makeText(this, "번역할 텍스트를 선택하세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        String target = containsHangul(text) ? "en" : "ko";
        String url = "https://translate.google.com/?sl=auto&tl=" + target + "&text=" + Uri.encode(text) + "&op=translate";
        openUri(url);
    }

    private void searchSelection() {
        String text = selectedOrClipboardText();
        if (TextUtils.isEmpty(text)) {
            Toast.makeText(this, "검색할 텍스트를 선택하세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        openUri("https://www.google.com/search?q=" + Uri.encode(text));
    }

    private void shareSelection() {
        String text = selectedOrClipboardText();
        if (TextUtils.isEmpty(text)) {
            Toast.makeText(this, "공유할 텍스트를 선택하세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, text);
            Intent chooser = Intent.createChooser(send, "텍스트 공유");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(chooser);
            hidePanel();
        } catch (Exception e) {
            Toast.makeText(this, "공유 화면을 열 수 없습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    private String selectedOrClipboardText() {
        KeyboardAccessibilityService a = KeyboardAccessibilityService.get();
        if (a != null) {
            String selected = a.getSelectedText();
            if (!TextUtils.isEmpty(selected)) return selected;
        }
        return readClipboardText();
    }

    private boolean containsHangul(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c >= '\uAC00' && c <= '\uD7A3') || (c >= '\u3131' && c <= '\u318E')) return true;
        }
        return false;
    }

    private void openUri(String uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            hidePanel();
        } catch (Exception e) {
            Toast.makeText(this, "열 수 있는 앱이 없습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    private void openAppSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception ignored) { }
        hidePanel();
    }

    private void openAccessibilitySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception ignored) { }
        hidePanel();
    }

    private void insertText(String text) {
        KeyboardAccessibilityService a = KeyboardAccessibilityService.get();
        if (a != null && a.insertText(text)) {
            rememberText(text);
            hidePanel();
            return;
        }
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(ClipData.newPlainText("text", text));
            rememberText(text);
            Toast.makeText(this, "클립보드에 복사했습니다. 접근성을 켜면 바로 입력됩니다.", Toast.LENGTH_SHORT).show();
        } else {
            accessibilityNeeded();
        }
    }

    private void accessibilityNeeded() {
        Toast.makeText(this, "텍스트 입력 기능을 쓰려면 접근성 권한을 켜세요.", Toast.LENGTH_SHORT).show();
    }

    private LinearLayout panelContainer() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(4), dp(2), dp(4), dp(4));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(panelBackgroundColor());
        bg.setCornerRadii(new float[]{dp(12),dp(12),dp(12),dp(12),0,0,0,0});
        content.setBackground(bg);
        return content;
    }

    private void addPanelTitle(LinearLayout content, String title) {
        TextView t = new TextView(this);
        t.setText(title + "    ×");
        t.setTextColor(panelTextColor());
        t.setTextSize(13f);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setPadding(dp(8), 0, dp(10), 0);
        t.setOnClickListener(v -> hidePanel());
        content.addView(t, new LinearLayout.LayoutParams(-1, dp(28)));
    }

    private TextView panelAction(String text, View.OnClickListener listener) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(panelTextColor());
        v.setTextSize(13f);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        v.setEllipsize(android.text.TextUtils.TruncateAt.END);
        v.setOnClickListener(listener);
        return v;
    }

    private int panelBackgroundColor() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        return dark ? Color.argb(235, 28, 28, 28) : Color.argb(235, 250, 250, 250);
    }

    private int panelTextColor() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        return dark ? Color.WHITE : Color.BLACK;
    }

    private int panelSubTextColor() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        return dark ? Color.LTGRAY : Color.DKGRAY;
    }

    private void showPanel(View content, int height) {
        hidePanel();
        if (windowManager == null || toolbar == null) return;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.BOTTOM;
        lp.y = dp(TOOLBAR_HEIGHT_DP);
        lp.setTitle("HardwareKeyboardToolbarPanel");
        try {
            windowManager.addView(content, lp);
            panel = content;
        } catch (Exception ignored) {
            panel = null;
        }
    }

    private void hidePanel() {
        if (panel == null || windowManager == null) return;
        try { windowManager.removeView(panel); } catch (Exception ignored) { }
        panel = null;
    }

    private void hideToolbar() {
        if (toolbar == null || windowManager == null) return;
        try { windowManager.removeView(toolbar); } catch (Exception ignored) { }
        toolbar = null;
    }

    private void captureClipboardIfReadable() {
        String text = readClipboardText();
        if (!TextUtils.isEmpty(text)) rememberText(text);
    }

    private String readClipboardText() {
        try {
            if (clipboardManager == null || !clipboardManager.hasPrimaryClip()) return null;
            ClipData clip = clipboardManager.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) return null;
            CharSequence cs = clip.getItemAt(0).coerceToText(this);
            return cs == null ? null : cs.toString();
        } catch (Exception ignored) {
            return null;
        }
    }

    private void rememberText(String text) {
        if (TextUtils.isEmpty(text) || text.length() > 5000) return;
        List<String> old = loadHistory();
        ArrayList<String> next = new ArrayList<>();
        next.add(text);
        for (String item : old) {
            if (!item.equals(text) && next.size() < MAX_HISTORY) next.add(item);
        }
        SharedPreferences.Editor e = prefs.edit().clear();
        e.putInt("history_count", next.size());
        for (int i = 0; i < next.size(); i++) e.putString("history_" + i, next.get(i));
        e.apply();
    }

    private List<String> loadHistory() {
        ArrayList<String> out = new ArrayList<>();
        int count = prefs == null ? 0 : Math.min(MAX_HISTORY, prefs.getInt("history_count", 0));
        for (int i = 0; i < count; i++) {
            String s = prefs.getString("history_" + i, null);
            if (!TextUtils.isEmpty(s)) out.add(s);
        }
        return out;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
