package com.bbq20kbd.toolbar.test;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class KeyboardAccessibilityService extends AccessibilityService {
    private static KeyboardAccessibilityService instance;

    public static KeyboardAccessibilityService get() {
        return instance;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // No event logging or test/diagnostic behavior. The service is only used
        // to edit the currently focused text field when a toolbar action is tapped.
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        if (instance == this) instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    private AccessibilityNodeInfo focusedEditableNode() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;

        AccessibilityNodeInfo node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (node != null && (node.isEditable() || node.isFocusable())) return node;

        AccessibilityNodeInfo focused = findFocusedEditable(root);
        if (focused != null) return focused;
        return node;
    }

    private AccessibilityNodeInfo findFocusedEditable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isFocused() && node.isEditable()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findFocusedEditable(node.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    public boolean insertText(String insertion) {
        if (insertion == null || insertion.isEmpty()) return false;
        AccessibilityNodeInfo node = focusedEditableNode();
        if (node == null) return false;

        CharSequence currentCs = node.getText();
        String current = currentCs == null ? "" : currentCs.toString();
        int start = node.getTextSelectionStart();
        int end = node.getTextSelectionEnd();
        if (start < 0 || start > current.length()) start = current.length();
        if (end < 0 || end > current.length()) end = start;
        int a = Math.min(start, end);
        int b = Math.max(start, end);

        String next = current.substring(0, a) + insertion + current.substring(b);
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, next);
        boolean ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        if (ok) setSelection(node, a + insertion.length(), a + insertion.length());
        if (ok) return true;

        ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cb != null) cb.setPrimaryClip(ClipData.newPlainText("text", insertion));
        return node.performAction(AccessibilityNodeInfo.ACTION_PASTE);
    }

    public boolean pasteClipboard() {
        AccessibilityNodeInfo node = focusedEditableNode();
        return node != null && node.performAction(AccessibilityNodeInfo.ACTION_PASTE);
    }

    public String getSelectedText() {
        AccessibilityNodeInfo node = focusedEditableNode();
        if (node == null || node.getText() == null) return null;
        String text = node.getText().toString();
        int start = node.getTextSelectionStart();
        int end = node.getTextSelectionEnd();
        if (start < 0 || end < 0 || start == end) return null;
        int a = Math.max(0, Math.min(Math.min(start, end), text.length()));
        int b = Math.max(0, Math.min(Math.max(start, end), text.length()));
        if (a >= b) return null;
        return text.substring(a, b);
    }

    public boolean copySelection() {
        String selected = getSelectedText();
        if (TextUtils.isEmpty(selected)) return false;
        ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cb == null) return false;
        cb.setPrimaryClip(ClipData.newPlainText("text", selected));
        return true;
    }

    public boolean cutSelection() {
        AccessibilityNodeInfo node = focusedEditableNode();
        if (node == null || node.getText() == null) return false;
        String text = node.getText().toString();
        int start = node.getTextSelectionStart();
        int end = node.getTextSelectionEnd();
        if (start < 0 || end < 0 || start == end) return false;
        int a = Math.max(0, Math.min(Math.min(start, end), text.length()));
        int b = Math.max(0, Math.min(Math.max(start, end), text.length()));
        if (a >= b) return false;

        String selected = text.substring(a, b);
        ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cb != null) cb.setPrimaryClip(ClipData.newPlainText("text", selected));

        String next = text.substring(0, a) + text.substring(b);
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, next);
        boolean ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        if (ok) setSelection(node, a, a);
        return ok;
    }

    public boolean selectAll() {
        AccessibilityNodeInfo node = focusedEditableNode();
        if (node == null || node.getText() == null) return false;
        return setSelection(node, 0, node.getText().length());
    }

    public boolean moveCursor(int delta) {
        AccessibilityNodeInfo node = focusedEditableNode();
        if (node == null || node.getText() == null) return false;
        int len = node.getText().length();
        int pos = node.getTextSelectionEnd();
        if (pos < 0) pos = len;
        pos = Math.max(0, Math.min(len, pos + delta));
        return setSelection(node, pos, pos);
    }

    public boolean moveCursorToEdge(boolean end) {
        AccessibilityNodeInfo node = focusedEditableNode();
        if (node == null || node.getText() == null) return false;
        int pos = end ? node.getText().length() : 0;
        return setSelection(node, pos, pos);
    }

    private boolean setSelection(AccessibilityNodeInfo node, int start, int end) {
        Bundle args = new Bundle();
        args.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, start);
        args.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, end);
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, args);
    }
}
