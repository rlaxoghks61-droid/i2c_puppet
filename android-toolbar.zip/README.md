# HW Keyboard Toolbar Test

Minimal Samsung/Android test app for checking whether a one-line bottom overlay can be shown only while a real external alphabetic hardware keyboard is connected.

## Behavior
- First launch opens Android's "Display over other apps" permission screen.
- After permission is granted, the background service starts automatically when returning to the app.
- External alphabetic hardware keyboard connected: 52dp bottom overlay toolbar appears.
- Keyboard removed: toolbar disappears.
- IME button opens Android's input-method picker.
- X hides the toolbar until the next input-device change / service start.

## Install
Build `app-debug.apk`, then:

    adb install -r app-debug.apk

Package:

    com.bbq20kbd.toolbar.test

## Stop completely

    adb shell am force-stop com.bbq20kbd.toolbar.test
